<?php

require_once APP_TESTS_LIB . '/testcase.php';

class Freelance_Unit_Tests extends APP_UnitTestCase {

	function test_test() {
		$this->assertTrue( true );
	}
}

