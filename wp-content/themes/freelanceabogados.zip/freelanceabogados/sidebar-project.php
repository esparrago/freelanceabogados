<!-- dynamic sidebar -->
<?php dynamic_sidebar('hrb-single-project'); ?>