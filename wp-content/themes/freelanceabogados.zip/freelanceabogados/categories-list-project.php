<?php
/**
 * Template Name: Projects Categories
 */
 ?>

<div class="row category-row">
	<div class="large-12 columns">
		<div class="categories-list">
	      <?php the_hrb_project_categories_list(); ?>
		</div>
	</div>
</div>
