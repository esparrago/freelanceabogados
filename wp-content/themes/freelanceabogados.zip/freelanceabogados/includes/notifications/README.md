notifications
=============

Provides notifications to themes.
