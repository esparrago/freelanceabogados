jQuery(document).ready(function($) {

	/* currencies dropdown - uses select2 */

	// init select2 JS
	$('#allowed_currencies').select2({
		closeOnSelect: false,
		width: '35em',
	});

});
