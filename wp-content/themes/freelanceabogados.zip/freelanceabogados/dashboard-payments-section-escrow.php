<div class="row">
	<div class="large-12 columns">
		<?php appthemes_display_escrow_form(); ?>
	</div>
</div>
