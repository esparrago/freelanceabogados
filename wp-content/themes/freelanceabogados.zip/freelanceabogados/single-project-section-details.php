<!-- project details tab-->
<div class="project-details row">
	<div class="columns large-12">

		<?php appthemes_before_post_content( HRB_PROJECTS_PTYPE ); ?>

		<?php the_content(); ?>

		<?php appthemes_after_post_content( HRB_PROJECTS_PTYPE ); ?>

	</div>
</div>