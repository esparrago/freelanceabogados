<div class="sidebar-widget-wrap cf">
	<?php dynamic_sidebar('hrb-profile'); ?>
</div>
