<?php hrb_before_post_section( HRB_PROJECTS_PTYPE, 'clarification' ); ?>

<?php comments_template(); ?>

<?php hrb_after_post_section( HRB_PROJECTS_PTYPE, 'clarification' ); ?>