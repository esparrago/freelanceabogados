<html>
<head>

</head>

<body <?php if ( is_rtl() ) echo 'style="direction:rtl;"'; ?> >
	<?php echo $content; ?>
</body>
</html>
