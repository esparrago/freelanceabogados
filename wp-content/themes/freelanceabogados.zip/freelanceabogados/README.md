HireBee - Premium WordPress Theme

Create your own full featured freelance marketplace with this premium theme.


You can find the entire installation guide online.
http://docs.appthemes.com/

For help and support, please post your questions in our forum.
http://forums.appthemes.com/



Enjoy your new premium application theme!


Your AppThemes Team
http://www.appthemes.com

** Please read the changelog.txt file for information on version modifications. **
