<div class="row workspace-type-reviewer">
	<div class="section-container project-trunk auto section-tabs" data-section>

		<section class="active">

			<p class="title" data-section-title="" style="left: 194px;"><a href="#manage"><?php echo __( 'Employer', APP_TD ); ?></a></p>

			<div class="content" data-section-content="">

				<?php appthemes_load_template( "dashboard-workspace-section-manage-employer.php" ); ?>

			</div>

		</section>

		<section>

			<p class="title" data-section-title="" style="left: 194px;"><a href="#manage"><?php echo __( 'Worker', APP_TD ); ?></a></p>

			<div class="content" data-section-content="">

				<?php appthemes_load_template( "dashboard-workspace-section-manage-worker.php" ); ?>

			</div>

		</section>

	</div>
</div>